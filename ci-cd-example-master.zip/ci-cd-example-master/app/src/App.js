import React from 'react';
import './App.css';

class App extends React.Component {
  
  render() {
    return (
      <div className="App">
        <div className="title">
          I am an Example App Running in the Cloud1
        </div>
      </div>
    );
  }
}

export default App;
